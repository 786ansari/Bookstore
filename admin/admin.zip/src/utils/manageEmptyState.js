const EmptyState = (states,image) => {
        if(image){
            image.current.value = ""
        }
    return states.map((val,i)=>{console.log("statesstates",val);
        return val("")
    })
}
export default EmptyState