const EmptyState = (stateArray) => {
        stateArray.map((item,i)=>{
            return item("")
        })
}

export default EmptyState