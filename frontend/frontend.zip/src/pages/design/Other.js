import React,{useState, useEffect} from "react";
const Other =() =>{
    return(
        <>
           <div className="row design-main">
           <div class="special-con"><div class="special-sub"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p></div></div>
             <div className="col-lg-3">
                <div className="design-sub">
                    <div className="design-img">
                    <img
                        src="../upload/47_upkar-B-2-jan-2018.jpg"
                        alt="img"
                        
                        />
                    </div>
                    <div className="design-file">
                    <a href="https://ab2software.com/sample.pdf" className="designa-img" download>
                        <p>EDITABLE ZIP FILE <span><i class="fa fa-download" aria-hidden="true"></i></span></p>
                    </a>
                    </div>
                </div>
             </div> 
             <div className="col-lg-3">
                <div className="design-sub">
                    <div className="design-img">
                    <img
                        src="http://localhost:8002/uploads/47_upkar-B-2-jan-2018.jpg"
                        alt="img"
                        
                        />
                    </div>
                    <div className="design-file">
                    <a href="https://ab2software.com/sample.pdf" className="designa-img" download>
                        <p>EDITABLE ZIP FILE <span><i class="fa fa-download" aria-hidden="true"></i></span></p>
                    </a>
                    </div>
                </div>
             </div> 
             <div className="col-lg-3">
                <div className="design-sub">
                    <div className="design-img">
                    <img
                        src="http://localhost:8002/uploads/47_upkar-B-2-jan-2018.jpg"
                        alt="img"
                        
                        />
                    </div>
                    <div className="design-file">
                    <a href="https://ab2software.com/sample.pdf" className="designa-img" download>
                        <p>EDITABLE ZIP FILE <span><i class="fa fa-download" aria-hidden="true"></i></span></p>
                    </a>
                    </div>
                </div>
             </div> 
             <div className="col-lg-3">
                <div className="design-sub">
                    <div className="design-img">
                    <img
                        src="http://localhost:8002/uploads/47_upkar-B-2-jan-2018.jpg"
                        alt="img"
                        
                        />
                    </div>
                    <div className="design-file">
                    <a href="https://ab2software.com/sample.pdf" className="designa-img" download>
                        <p>EDITABLE ZIP FILE <span><i class="fa fa-download" aria-hidden="true"></i></span></p>
                    </a>
                    </div>
                </div>
             </div> 
           </div>           
        </>
    )
}
export default Other