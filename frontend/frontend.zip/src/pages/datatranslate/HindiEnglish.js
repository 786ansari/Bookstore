import React,{useState, useEffect} from "react";
const HindiEnglish =() =>{
    return(
        <>
          HindiEnglish
        </>
    )
}
export default HindiEnglish