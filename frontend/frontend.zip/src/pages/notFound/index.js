const NotFound = () => {
    return (
        <h3>Not Found</h3>
    )
}
export default NotFound