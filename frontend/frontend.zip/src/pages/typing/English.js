import React,{useState, useEffect} from "react";
const English =() =>{
    return(
        <>
           English
        </>
    )
}
export default English