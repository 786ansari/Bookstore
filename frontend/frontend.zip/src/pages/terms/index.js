import SlideShow from "../../Components/Slideshow/Slideshow"
import Footer from "../../comman/Footer"
import Header from "../../comman/Header"

export const Terms = () => {
    return (
        <>
        {/* <SlideShow/> */}
        <Header/>
        <h4>Terms & Condition</h4>
        <Footer/>
        </>
    )
}