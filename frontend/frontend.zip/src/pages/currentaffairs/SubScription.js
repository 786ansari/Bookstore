import React, {useState, useEffect} from "react";
const SubScription = ()=>{
    return(
        <div>sub</div>
    )
}
export default SubScription;